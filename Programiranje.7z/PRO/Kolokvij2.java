package kolokvijVaje;

import java.util.Scanner;

public class Kolokvij2 {


/*Napi�ite metodo, ki vrne izbrano opcijo menija, ki jo izbere uporabnik.
Opcije menija so:
1 - izpis lika trikotnika
2 - izpis lika kvadrata
3 - izpis lika pravokotnika
0 - konec dela
public static int meniIzbor () 
Npr. klic metode  meniIzbor () vrne eno izmed vrednosti (1, 2, 3, 0).
Opcije menija se izpisujejo dokler uporabnik ne izbere ene izmen ponujenih */

	public static int meniIzbor1 () {
		// objekt za branje s tipkovnico
		Scanner tipkovnica = new Scanner(System.in);
		int izbor; // spremenljivka za ibor
		do {
		//izpis mo�nosti 
		System.out.printf("\n 1 - izpis lika trikotnika");
		System.out.printf("\n 2 - izpis lika kvadrata");
		System.out.printf("\n 3 - izpis lika pravokotnika");
		System.out.printf("\n 0 - konec dela");
		System.out.printf("\n 1 - Izbor: ");
		izbor = tipkovnica.nextInt();
		} while (izbor < 0 || izbor > 3);
		
		tipkovnica.close();
		return izbor;
		
	}//konec meniIzbor
	public static void main(String[] args) {
		System.out.printf("Va� izbor je: %d", meniIzbor1());
	
		
	}//main

}//class
