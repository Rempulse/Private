import java.util.Scanner;

/*Uporabnik vnese začetno stanje glavnice, obrestno mero (letno) in Število let.
Program po letih izpiŠe leto in stanje v tistem letu.

Novo stanje za tekoče leto(i-to leto)= začetno stanje * Math.pow(1.0 + obrestna mera, leto)*/
// a= 1+obrestna mera
// b= leto



public class v4_3 {

	public static void main(String[] args) {
	//objekt za branje s tipkovnice
	Scanner tipkovnica = new Scanner(System.in);
	//najava spremlenljivk
	
	int steviloLet;
	float glavnica;//začetno stanje denarja za varčevanje
	float obrestnaMera;
	
	// obvestilo za vnos in branje vrednosti
	System.out.print("Začetno stanje (Glavnica): ");
	glavnica = tipkovnica.nextFloat(); // branje vrednosti
	System.out.print("Obrestna mera <2 % - 0,02>: "); 
	obrestnaMera = tipkovnica.nextFloat(); // branje vrednosti
	System.out.print("Število let varčevanja: ");
	steviloLet = tipkovnica.nextInt(); // nextInt ker je int
	//zapremo vhodni tok
	tipkovnica.close();
	// zanka i=1..steviloLet
	int i = 1; //inicializacija števca
	//spremenljivka za izračun 
    double novoStanje;
	// dokler je i manjši ali enako število let
	while (i <= steviloLet) {
		//glavnica * Math.pow(1.0 + obrestna mera, i)
	novoStanje = glavnica * Math.pow(1.0 + obrestnaMera, i);
	System.out.printf("\nStanje po %d. letu je: %.2f.", i, novoStanje);
	     // povečamo števec
		i = i + 1; 
	}// konec zanke while
	
	
		
	}//class

}//main
