
/* Program za deset vnesenih celih �tevil izpi�e �tevilo pozitivnih 
in �tevilo negativnih �tevil.*/


package v1_2;

import java.util.Scanner;

public class V3_1 {

	public static void main(String[] args) {
		// najava in inicalizacija �tevcev
		int steviloPozitivnih = 0, steviloNegativnih = 0;
		
		float stevilo;
		// usvarimo objekt za delo s tipkovnico
		Scanner tipkovnica = new Scanner(System.in);
		
		//zanka , iteracija, i = 1...10
		for (int i=1; i<=10; i=i+1) {
			//obestilo za vnos
			System.out.printf("Vpi�i %d. �tevilo: ", i);
			//branje i-tega �tevila
			stevilo = tipkovnica.nextFloat();
			if (stevilo >= 0) //pozitivno
			   steviloPozitivnih = steviloPozitivnih + 1; 
			else
				steviloNegativnih =  steviloNegativnih +1;
			
		}//for
		//zapremo vhodni tok
		tipkovnica.close();
		// izpis vrednosti pozitivnih in negativnih �tevil
		System.out.printf("\n�tevilo pozitivnih �tevil: %d", steviloPozitivnih);
		System.out.printf("\n�tevilo negativnih �tevil: %d", steviloNegativnih);
		
	} // main

}// class
