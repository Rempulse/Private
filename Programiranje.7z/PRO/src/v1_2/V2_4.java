package v1_2;
/*Program  za osebo izpiše ali ima premajhno telesno težo ali ima normalno telesno težo ali  ima preveliko telesno težo.
Uporabnik vnese višino v metrih in telesno težo v kilogramih.

Glede na ta dva podatka se izračuna koeficient po formuli koeficient = teža / (višina * višina).
Če je koeficient pod 18.5 => "premajhna teža", če je med 18.5 in 25.5 => "normalna teža", sicer pa je teža "prevelika  teža".

Vnesi višino (metri) in težo osebe (kg): 1.72 64
Telesna teža je: normalna teža */

import java.util.Scanner;

public class V2_4 {

	public static void main(String[] args) {
		//dekleracija spremenljivk, teža, višina
		
		float visina, teza;
		
		// ustvarimo objekt za branje s tipkovnice 
		Scanner tipkovnica = new Scanner(System.in);
		
		//obvestilo za vnos
		
		System.out.print("Višina (v metrih): ");
		visina = tipkovnica.nextFloat(); //branje višine
		
		System.out.print("Teža (v kg): ");
		teza = tipkovnica.nextFloat(); //branje teže
		//zapremo objekt za delo s tipkovnico
        tipkovnica.close();
        
        //izračun koeficient = teža / (višina * višina)
        float koeficient = teza / (visina * visina);
        
        if (koeficient <= 18.5) {
        	   System.out.printf("Teža je premajhna.");
		} else 
		     if (koeficient <= 25.5)
			    System.out.printf("Teža je ustrezna.");
		  else
			   System.out.printf("Teža je prevelika.");
      
          
          
		 }
	    }
       }
