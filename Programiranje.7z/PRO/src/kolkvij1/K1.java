package kolkvij1;

import java.util.Scanner;

public class K1 {
	
	
/*Napi�ite metodo, ki vrne izbrano opcijo menija, ki jo izbere uporabnik.
Opcije menija so:
A - izpis lika trikotnika
B - izpis lika kvadrata
C - izpis lika pravokotnika
K - konec dela
public static char meniIzbor () 
Npr. klic metode  meniIzbor () vrne eno izmed vrednosti ('A', 'B', 'C', 'K').
Opcije menija se izpisujejo dokler uporabnik ne izbere ene izmen ponujenih mo�nosti.
*/
	
	
	public static char meniIzbor() {
		//objekt za delo s tipkovnico
		Scanner tipkovnica = new Scanner(System.in);
		char izbor;
		do {
		
		
	     	//izpis opcij
		 System.out.println("A - izpis lika trikotnika");
		 System.out.println("B - izpis lika kvadrata");
		 System.out.println("C - izpis lika pravokotnika");
		 System.out.println("K - konec dela");
		 System.out.println("Izbor: ");
		 izbor = tipkovnica.next().toUpperCase().charAt(0); //chartAt vrne prvi znak
		
		

		} while (izbor != 'A' && izbor != 'B' && izbor != 'C' && izbor != 'K');
		return izbor;
		
	}//meniIzbor
	
	
	


	public static void main(String[] args) {
		char izbor = meniIzbor();

	}

}
