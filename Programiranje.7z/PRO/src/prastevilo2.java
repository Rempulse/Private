
public class prastevilo2 {
 public static boolean prastevilo (int stevilo ) {
	 boolean prastevilo = true;
	 int i = 2;
 }
 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
