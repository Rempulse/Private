
public class prastevilo {

	 
	// vrne true �e je vhodni argument pra�tevilo
		public static boolean prastevilo (int stevilo) {
			if (stevilo < 2) // �e je �tevilo manj�e od 2 
				return false; 
			//najava spremenljivk
			boolean prastevilo = true; // zastavica za pra�tevilo
			int i = 2; // �tevec inicializiramo na 2
			//dokler �e velja da je pra�tevilo in �tevec i < stevilo /2
			while (prastevilo && i <= stevilo/2) {
				prastevilo = stevilo % i!=0;
				i = i + 1; //pove�anje �tevca
			}//stavek while
			return prastevilo;
		}// prastevilo
		
		//izpis �tevil iz obmo�ja odStevila do DoStevila
		// ki so deljiva s tri pet.
	public static String deljivaTriAliPet(int odStevila, int doStevila) {
		//inicializacija praznega besedila za rezultat
		String seznamDeljivih = "";
		//zanka i = odStevila... doStevila korak (1)
		for (int i= odStevila; i<= doStevila; i++) { //i=i+1 = i++
			if (i % 3 == 0 || i % 5 == 0 ) // == je enako testira
				if(seznamDeljivih.equalsIgnoreCase("") )
				seznamDeljivih = seznamDeljivih + ", " + i;
				else
				seznamDeljivih = seznamDeljivih + ", " + i;
			
		}//for
		
		return seznamDeljivih;
		
		}//deljivaTriAliPet
		

		public static void main(String[] args) {
			/*int stevilo1 = 10;
			if (prastevilo(stevilo1))
			System.out.printf("\n�tevilo %d je pra�tevilo. ", stevilo1);
			else
			System.out.printf("\n�tevilo %d ni pra�tevilo. ", stevilo1);*/
			int spodnjaMeja = 10;
			int zgornjaMeja = 30;
			String seznam = deljivaTriAliPet(spodnjaMeja, zgornjaMeja);
			//izpis
			System.out.printf("Seznam deljivih: %s", seznam); 
	}//main 

}//Razred
