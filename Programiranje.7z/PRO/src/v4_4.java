import java.util.Scanner;

/*Frekvenca pojavitev posameznih ocen Študentov

Uporabnik vnaŠa ocene Študentov dokler ne vnese 0.
Program določi in izpiŠe frekvence pojavitev posameznih ocen.

VpiŠi oceno med 6 in 10 (0 za konec): 7
VpiŠi oceno med 6 in 10 (0 za konec): 8
VpiŠi oceno med 6 in 10 (0 za konec): 7
VpiŠi oceno med 6 in 10 (0 za konec): 9
VpiŠi oceno med 6 in 10 (0 za konec): 7
VpiŠi oceno med 6 in 10 (0 za konec): 3
Vnesena je bila napačna ocena.
VpiŠi oceno med 6 in 10 (0 za konec): 10
VpiŠi oceno med 6 in 10 (0 za konec): 0*/



public class v4_4 {

	public static void main(String[] args) {
		// objekt za branje s tipkovnice
		Scanner tipkovnica = new Scanner(System.in);
		//spremenljivka za oceno
		int ocena;
		//spremenljivke za štetnje ocen
		int ocena6 = 0, ocena7 = 0, ocena8 = 0, ocena9 = 0, ocena10 = 0;
	
		//ponavljal dokler je ocen <> različna od 0
		do {
			//obvestilo za vnos 
			System.out.print("Ocena <0-konec vnosa>: ");
			ocena = tipkovnica.nextInt();
			//ko vemo za oceno povečamo ustrezni števec ocen
			if (ocena!=0) {
				switch (ocena) {
				case 6: ocena6 = ocena6 + 1;
					    break;
				case 7: ocena7 = ocena7 + 1;
						break;
				case 8: ocena8 = ocena8 + 1;
						break;
				case 9: ocena9 = ocena9 + 1;
						break;
				case 10: ocena10 = ocena10 + 1;
						break;
				default: 
					System.out.printf("\nNapaka...neustrezna ocena: ");
				}// switch
			}// if
		} while (ocena != 0); 
		//zapremo vhodni tok delo s tipkovnico
		tipkovnica.close();
		
	// izpis štetja ocen
	System.out.printf("\nOcena %d; število pojavitev: %d", 6, ocena6);
	System.out.printf("\nOcena %d; število pojavitev: %d", 7, ocena7);
	System.out.printf("\nOcena %d; število pojavitev: %d", 8, ocena8);
	System.out.printf("\nOcena %d; število pojavitev: %d", 9, ocena9);
	System.out.printf("\nOcena %d; število pojavitev: %d", 10, ocena10);
	
	}//class

}//main
