/*Npr. klic najvecjiZnak (abcdf12345) vrne vrednost 'z'.
 *primerjava znakov glede na mesto v kodni tabeli*/
public class KolokvijNajvecjiZnak {
	
public static char najvecjiZnak (String besedilo) {
	if (besedilo == null || besedilo.length() == 0 )
		return '~';
	// prvi znak besedila inicializiramo kot najve�ji znak
	char najZnak = besedilo.charAt(0);
	// zanka �tevec i od drugega do zadnjega znaka
    // i = 1.. besedilo.length()-1
	for(int i = 1; i < besedilo.length(); i++)  {		// �ekiramo �e je znak na indeksu i ve�ji od dosedaj najve�jega
		if (besedilo.charAt(i) > najZnak)
			najZnak = besedilo.charAt(i);
	
	}// for
	
	return najZnak;
	
}

	public static void main(String[] args) {
		String niz = "BBBCCCAAA";
		System.out.printf("Najve�ji znak v nizu %s je %s.", niz, najvecjiZnak(niz));
		
		

	}//main

}//class
