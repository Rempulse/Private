
public class Geslo {
/*ustvari naklju�no geslo - dol�ine n znakov (n vhodni argument
 *geslo vsebuzje angle�ke znake- male �rke)*/
	
	public static String nakjlucnoGeslo(int n) {
		String geslo = "";
		char znak;
		// zanka i = 1...n
		for(int i=1; i <=n; i++) {
			//naklju�ni znak 'a' - 97, 'z' -122
			znak = (char)(int) (Math.random() * (122-97+1) + 97);
			//znak dodamo na konec dosedanjega gesla
			geslo = geslo + znak; // lepimo sting+int nese�teje
			
		
			
		}//for
		return geslo;
	}
	

	
	
	public static void main(String[] args) {
		String geslo = nakjlucnoGeslo(6);
		System.out.printf("Naklju�no geslo je %s." , geslo);
		

	}

}
