package kolokvijVaje;

import java.util.Scanner;

public class Kolokvij {
	
	public static int najvecjaStevilkaA(long stevilo) {
		
		long ostanek;
		long najvecjiZnak=0;
		
		while(stevilo>0) {
			ostanek=stevilo%10;
			if(ostanek>najvecjiZnak)
				najvecjiZnak=ostanek;
			stevilo=stevilo/10;
		}
		return (int)najvecjiZnak;
	}
	
	public static int najvecjaStevka(long stevilo) {
		String txtStevilo=Long.toString(stevilo);
		
		char najvecjiZnak='0';
		
		for(int i=0; i<txtStevilo.length(); i++){
			if(txtStevilo.charAt(i)>najvecjiZnak)
				najvecjiZnak=txtStevilo.charAt(i);
		}
		return (int)najvecjiZnak;
	}
	
	public static char meniIzbor() {
		char izbor = 0;
		
		do{
			System.out.println("A - izpis lika trikotnika");
			System.out.println("B - izpis lika kvadrata");
			System.out.println("C - izpis lika pravokotnika");
			System.out.println("K - konec dela");
			System.out.println("Izbor: ");
			
			izbor = new Scanner(System.in).next().charAt(0);
		}while("ABCKabck".indexOf(izbor)==-1);
		
		return izbor;
	}
	public static void main(String[]args) {
		/*char izborMenija = meniIzbor();
		System.out.printf("Va� izbor: %s", izborMenija); */
		
		/*long stevilo=2561;
		System.out.printf("Najvecja �tevka �tevila %d je %s", stevilo, (char)najvecjaStevka(stevilo)); */
	
		long stevilo=2562;
		System.out.printf("Najvecja �tevka �tevila %d je %s", stevilo, najvecjaStevilkaA(stevilo));
	}
}
