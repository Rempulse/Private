package kolokvijVaje;

public class E {

	/*Napi�ite metodo, ki izpi�e �rko E z dolo�enim �tevilom vrstic in stolpcev (slika).
public static void izpisZnakE (int steviloVrstic, int steviloStolpcev) 
Npr. klic  izpisZnakE (5, 4) izpi�e:

*	*	*	*
*			
*	*	*	*
*			
*	*	*	*
*/
	
	public static void izpisZnakE (int steviloVrstic, int steviloStolpcev) {
	
	//zunanja zanka vrstice, �tevec i = 1..	steviloVrstic
		
	for (int i=1; i <= steviloVrstic; i++) {
		// �e je prva, sredinska ali zadnja vrstica
		if (i == 1 || i == steviloVrstic || i == (1+steviloVrstic) /2) {
			//zanka stolpci �tevec j = 1.. steviloStolpcev
			for (int j=1; j <= steviloStolpcev; j++)
				//izpis znaka '*'
				System.out.print('*');
		}
		
		else {
			//zvezdica v prvem stolpcu
			 System.out.print('*');
			}//if
		// premikv novo vrstico
		System.out.println();
	
	}//for vrstice
		
		
	}//konec izpisZankE
	
	
	
	public static void main(String[] args) {
		izpisZnakE(8, 7);


	}

}
