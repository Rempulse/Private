
public class V5_1 {
	
	public static String stevilaDeljiva3ali5(int odStevila, int doStevila) {
		String seznam = "";	
		
		for (int i=odStevila; i<=doStevila; i++) {
			if(i%3==0 || i%5==0)
				if (seznam.length()>0)
					seznam = seznam + ","+i;
				else
					seznam = seznam + i;
		}
		return seznam;
	}
	
	public static boolean jePrastevilo(int stevilo){
		
		if(stevilo<2)
			return false;
		
		boolean prastevilo = true;
		
		int i=2;
		
		while (prastevilo && i <= stevilo / 2) {
			
			prastevilo = stevilo % i != 0;
			
			i++;
			
			
		}
		
		return prastevilo;
	}
	public static void main (String[]args) {
		
		/*
		int stevilo1 = 11;
		if(jePrastevilo(stevilo1))
			System.out.printf("�tevilo %d je pra�tevilo.",stevilo1);
		else
			System.out.printf("�tevilo %d ni pra�tevilo.", stevilo1);
			
			*/
		
		int spodnjaMeja = 10;
		int zgornjaMeja = 30;
		String seznamStevil = stevilaDeljiva3ali5(spodnjaMeja, zgornjaMeja);
		System.out.printf("Seznam deljivih �tevil: %s", seznamStevil);
		
	}
}
