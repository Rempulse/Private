
package kolokvijVaje;

public class Krneki {
/*
Napi�ite metodo, ki vrne najve�jo �tevko oz. cifro celo�tevil�nega vhodnega parametra.
public static int najvecjaStevka (long stevilo)  
Npr.  klic  najvecjaStevka (2831) vrne vrednost 8.
*/

public static int najvecjaStevka (long stevilo) {
	long najStevka = 0; //inicializacija
	long zadnjaStevka; //spremenljivka za zadno �tevko
	
	//dokler je stevilo ve�je od 0
	while (stevilo > 0 ) {
		//dolo�imo vrednost zadnje �tevke v spremenljivki stevilo
		zadnjaStevka = stevilo % 10;
		// �e je ve�ja od do sedaj najve�je 
		if (zadnjaStevka > najStevka) {
			najStevka = zadnjaStevka;
		}//konec if
		// dolo�imo �tevilo brez zadnje �tevke 
		stevilo = stevilo / 10;
	}//while
	
	
	return (int) najStevka;
}//najvecjaStevka

 public static int najvecjaStevkaNiz(int stevilo) {
	 //stevilo pretvorimo v objekt razreda String
	 String steviloNiz = Integer.toString(stevilo);
	 char najStevkaZnak = '0'; //inicializacija
	 //zanka �tevec i = 0... �tevilo zankov niza -1
	 for (int i = 0; i <= steviloNiz.length(); i++) {
		// �e je zank na indeksu i ve�ji od do sedaj najve�jega znaka
		 
		 if (steviloNiz.charAt(i) > najStevkaZnak) 
			 najStevkaZnak = steviloNiz.charAt(i);
		 
		
		 
	 }//konec for
	 
	 
	 
	 
	
	 return (int) najStevkaZnak;
 }//najvecjaStevkaNiz
 
 
 
 
 
 
 
public static void main(String[] args) {
int stevilo = 6842;
System.out.printf("Najvecja �tevka �tevila %d je %d. ", stevilo, najvecjaStevkaNiz(stevilo));
		

}//main

}//class
