package B23_1;

import java.util.Scanner;

/*Program za izračun vsote dveh vnesenih celih števil.
Vpiši dve celi števili: 45 78
Prvo število je: 45
Drugo število je: 78
Vsota števil je 123.*/
public class V1_3 {

	public static void main(String[] args) {
		// pred uporabo najavimo spremenljivke - dekleracija spremenljivk
		int  stevilo1, stevilo2;
		
		// za branje s tipkovnice uporabljamo metode razreda Scanner
		// ustvarimo objekt razreda Scanner
		
		Scanner tipkovnica = new Scanner (System.in);
		// obvestilo za vnos
		System.out.printf("Vpiši dve celi števili: ");
		//branje - vrednosti sharnimo v spremenljivke
		stevilo1 = tipkovnica.nextInt();
		stevilo2 = tipkovnica.nextInt();	
		
		// izračun vsote
		int vsota = stevilo1 + stevilo2;
		
		// izpis v konzolno okno
		System.out.printf("Vsota števil: %d + %d = %d.",
		stevilo1, stevilo2, vsota);
		
		

		
		

	}

}
