package B23_1;

import java.util.Scanner;

public class V1_4 {
/*Program za izračun ploščine in obsega pravokotnika.
Podatki pravokotnika:
Stranica a: 3.5
Stranica b: 2.45
-----------------------------------
Obseg pravokotnika je 11.9.
Ploščina pravokotnika je 8.575. */
	
	
	
	public static void main(String[] args) {
		//spremenljivki stranici-Float
		
		float stranicaA,  stranicaB;
		// objekt za branje s tipkovnice 
		Scanner tipkovnica = new Scanner (System.in);
		System.out.printf("Vpiši dve stranici: ");
		stranicaA = tipkovnica.nextFloat();
		stranicaB = tipkovnica.nextFloat();
		
		float obseg= (stranicaA * 2) + (stranicaB * 2);
		System.out.printf("Obseg pravokotnika: %.2f", obseg);
		
		float ploscina= stranicaA * stranicaB;
		System.out.printf("Obseg pravokotnika:%.2f", ploscina);
		
		
		
		
		
		

	}

}
