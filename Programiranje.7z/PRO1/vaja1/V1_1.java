package B23_1;
//Vaja1_1 Program na zaslon izpi�e obvestilo "To je prvi primer na vajah." To je prvi primer na vajah.

public class V1_1 {

	public static void main(String[] args) {
		// Izpis-printf
		System.out.printf("To je prvi primer na vajah.");
		

	}

}
