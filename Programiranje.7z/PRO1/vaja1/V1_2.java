package B23_1;

/*Program na zaslon izpi�e obvestilo.
Ime: <Va�e ime npr. Marko>
Priimek: <Va� priimek npr. Koren>
E-naslov: <Va� elektronski naslov> */
public class V1_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.printf("Ime: \t\t�an\n");
		System.out.println("Priimek: \tNovak");
		System.out.printf("E-naslov: \tzan.novak96@gmail.com");
		
		
		
	} // main

} // V1_2
