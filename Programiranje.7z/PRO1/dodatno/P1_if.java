package p2901;

import java.util.Scanner;

/*vpi�emo �tevilo to�k 
program izpi�e vrednost ocene */

public class P1_if {

	public static void main(String[] args) {
	// obvestilo za vnos to�k
	 System.out.print("�tevilo to�k: ");
	 // branje z anonimnim objektom razreda Scanner
	 int stTock = new Scanner(System.in).nextInt();
	 //najava spremenljivke ocena
	 int ocena;
	 if (stTock < 50)
		 ocena = 5;
	 else
		 if (stTock < 60)
			 ocena = 6;
		 else 
			 if(stTock < 70)
				 ocena = 7;
			 else 
				 if(stTock < 80)
					 ocena = 8;
				 else
					 if (stTock <90)
						 ocena = 9;
					 else 
						 ocena = 10;
	 // izpis ocene
	 System.out.printf("Ocena je %d.", ocena);
	 
	

	}

}
