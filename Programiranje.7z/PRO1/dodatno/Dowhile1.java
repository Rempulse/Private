import java.util.Random;
import java.util.Scanner;

/*UGIBANJE �TEVILA IZ INTERVALA OD 1 DO 20*/
public class Dowhile1 {

	public static void main(String[] args) {
		//Spremenljvika za nakljucno stevilo - ustvari ra�.
		int nakljucnoStevilo;
		/*za ustvarjanje naklju�nega �tevila 
		uporabimo objekt razreda Random */
		Random nakljucno = new Random();
		//dolo�imo naklju�no �tevilo
		nakljucnoStevilo = nakljucno.nextInt(20) + 1;
		// ustvarimo objekt za branje - tipkovnica
		Scanner tipkovnica = new Scanner(System.in);
		
		
		// najava spremenljivke za vpis ugibanja �tevila
		int steviloUporabnik;
		//spremenljivka za �tetje �tevila ugibanj
		int steviloUgibanj = 0;
		// zanka stavek do while 
		do {
			steviloUgibanj = steviloUgibanj + 1; //pove�amo �tevec ugibanj
		  //obvestilo za vnos
			System.out.printf("\nUgani �tevilo med <1-20>, %d.ugibanje: ", steviloUgibanj);
			steviloUporabnik = tipkovnica.nextInt();
			if (steviloUporabnik < nakljucnoStevilo) // �e je manj�e
				System.out.printf("\nPoskusite vpisati ve�je �tevilo");
			else 
			    if (steviloUporabnik > nakljucnoStevilo);
			    System.out.printf("\nPoskusite vpisati manj�e �tevilo");
			    
			// != razli�no
		} while (steviloUporabnik != nakljucnoStevilo);
		// obvestilo
		System.out.printf("�estitke...uganili ste v %d ugibanju", steviloUgibanj);	
		
	

	}// main

}// razred DoWhile
