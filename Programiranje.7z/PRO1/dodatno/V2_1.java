/* Program, ki za dve vneseni realni �tevili izpi�e vrednosti 
relacijskih izrazov: >, >=, <, <=, !=,  ==.*/


package v25_1;

import java.util.Scanner;

public class V2_1 {

	public static void main(String[] args) {
		// najava dveh spremenljivk 
		float stevilo1, stevilo2;
		
		//objekt za delo s tipkovnico
		Scanner tipkovnica= new Scanner(System.in);
	    // obvestilo za vnos
		System.out.print("Vpi�i dveh �tevil: ");
		//branje
		stevilo1 = tipkovnica.nextFloat();
		stevilo2 = tipkovnica.nextFloat();
		tipkovnica.close(); // zapremo tipkovnico
		
		//stevilo1 > stevilo2
	    if (stevilo1 > stevilo2)	
	    	System.out.printf("\n %.2f > %.2f: %s", stevilo1, stevilo2, "resni�no");
	    else
	    	System.out.printf("\n %.2f > %.2f: %s", stevilo1, stevilo2, "neresni�no");
		
		//stevilo>=stevilo2
	    if (stevilo1 >= stevilo2)	
	    	System.out.printf("\n %.2f >= %.2f: %s", stevilo1, stevilo2, "resni�no");
	    else
	    	System.out.printf("\n %.2f >= %.2f: %s", stevilo1, stevilo2, "neresni�no");
		
		//stevilo<stevilo2
	    if (stevilo1 < stevilo2)	
	    	System.out.printf("\n %.2f < %.2f: %s", stevilo1, stevilo2, "resni�no");
	    else
	    	System.out.printf("\n %.2f < %.2f: %s", stevilo1, stevilo2, "neresni�no");
		
		//stevilo<=stevilo2
	    if (stevilo1 <= stevilo2)	
	    	System.out.printf("\n %.2f <= %.2f: %s", stevilo1, stevilo2, "resni�no");
	    else
	    	System.out.printf("\n %.2f <= %.2f: %s", stevilo1, stevilo2, "neresni�no");
		
	  //stevilo!=stevilo2
	    if (stevilo1 != stevilo2)	
	    	System.out.printf("\n %.2f != %.2f: %s", stevilo1, stevilo2, "resni�no");
	    else
	    	System.out.printf("\n %.2f != %.2f: %s", stevilo1, stevilo2, "neresni�no");
		
	  //stevilo==stevilo2
	    if (stevilo1 == stevilo2)	
	    	System.out.printf("\n %.2f == %.2f: %s", stevilo1, stevilo2, "resni�no");
	    else
	    	System.out.printf("\n %.2f == %.2f: %s", stevilo1, stevilo2, "neresni�no");
		
	    
	    
		
	}

}
