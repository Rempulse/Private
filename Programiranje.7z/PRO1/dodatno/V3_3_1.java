import java.util.Scanner;

/*izpis ve�kratnikov �tevila 4 na zaslon
 * ki so manj�i ali enaki 100  */

public class V3_3_1 {

	public static void main(String[] args) {
		// �tevec i inicializiramo na 4
		int i = 4;
		while (i <= 100) {
			
		// izpis vrednosti �tevca i
			System.out.println(i);
		//pove�amo i za 4
			i = i + 4;
			}//konec zanke while
		}
     }



