import java.util.Scanner;

/*vpisovanje �tevila to�k dokler 
ne vpi�emo vrednosti od -1 do 100*/
public class DoWhile2 {

	public static void main(String[] args) {
		int steviloTock;
		// objekt razreda Scanner za delo s tipkovnico
		Scanner tipkovnica = new Scanner(System.in);
		// spremenljivka za vsota to�k
		float vsotaTock = 0;
		// �tevec vpisanih ocen
		int steviloVpisanihTock = 0;
		
		do {
		
		// ponavljanje vnosa dokler uporabnik ne vpi�e ustreznega �tevila
		do {
			//obvestilo za vnos 
			System.out.println("�tevilo <-1...100>: ");
			steviloTock = tipkovnica.nextInt(); //branje
		} while (steviloTock < -1 || steviloTock > 100);
		//�e ni konec vnosa -1
		if (steviloTock != -1) {
			//pove�amo vsoto to�k
			vsotaTock = vsotaTock + steviloTock;
		//pove�amo �tevec vpisanih ocen
	     steviloVpisanihTock++; // steviloVpisanihTock=steviloVpisanihTock+1
			
			
		} // konec if-a
		
		} while(steviloTock != -1); //razli�no od -1..konec vnosa
		//izpis vsote to�k
		System.out.printf("\nVsota to�k: %.2f", vsotaTock);
		System.out.printf("\n�tevilo ocen : %d.", steviloVpisanihTock);
		// izra�un povpre�je
		System.out.printf("\nPovpre�je �tevila To�k: %.2f",
				vsotaTock / steviloVpisanihTock );
		// zapremo delo s tipkovnico
		tipkovnica.close();
	
		
		
	

	}

}
