import java.util.Scanner;

/*
 *Program s pomočjo zvezdic izriŠe pravokotni trikotnik.
Uporabnik vnese viŠino trikotnika (Število vrstic).

ViŠina trikotnika: 8
Lik:

********
*******
******
*****
****
***
**
*  
 */



public class v3_3 {

	public static void main(String[] args) {
		//spremenljivke za vrstice
		int b ; //b- število vrstic
		//ustvarimo objekt za delo s tipkovnico
		Scanner tipkovnica = new Scanner(System.in);
		//obvestilo za vnos
		System.out.print("Število vrstic: ");
		//branje
		b = tipkovnica.nextInt();
		//zanka za vrstice, števec i = b...1
		//inicializacija števca zanke
		int i = b;
		while (i >= 1) {
		//zanka za vse stolpce, j = 1... i
		 int j = 1;
		 while (j <= i) {
			// izpis znak '*'
			 System.out.print('*');
			// sprememba števca 
			 j = j + 1;
		 }//zanka stolpci 
		 //premik v novo vrstico
		 System.out.println();
		//zmanjševanje števca i
			i = i - 1;
		
		}//zanka vrstic
		
	}//main
	}//class
		
			