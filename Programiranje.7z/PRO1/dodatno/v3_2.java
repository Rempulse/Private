import java.util.Scanner;

/*Program s pomočjo zvezdic izriŠe pravokotnik dimenzij a (Število stolpcev) in b (Število vrstic).
Dimenzije vnese uporabnik.

Â Število stolpcev: 12

Število vrstic: 6Â 

Lik: pravokotnik

************
************
************
************
************
************ 
*/
    public class v3_2 {

	public static void main(String[] args) {
		//spremenljivke za dimenzije pravokotnika
		int a, b; //b - število vrstic, a - število stolpcev
		//ustvarimo objekt za delo s tipkovnico
		Scanner tipkovnica = new Scanner(System.in);
		//obvestilo za vnos
		System.out.print("Število vrstic: ");
		//branje
		b = tipkovnica.nextInt();
		//obvestilo za vnos
		System.out.print("Število stolpcev: ");
		//branje 
		a = tipkovnica.nextInt();
		//zapremo vhodni tok
		tipkovnica.close();
		// zunanja zanka, vrstice, števec i = 1...b korak 1 
		int i = 1;
		while (i <= b) {
			//zanka, stolpci, števec j = 1..a korak 1
			int j = 1;
			
			while (j <= a) {
				// izpis znaka '*'
				System.out.print('*');
			//povečamo števec
				j = j + 1;
			} //while stolpci
		     //premik v novo vrstico
			System.out.println();
			//povečamo števec
			i = i +1;
		}// konec stavka while za vrstice
		
	
		
	}

}

		
		
		
		
		
		
		
		
	}

}
