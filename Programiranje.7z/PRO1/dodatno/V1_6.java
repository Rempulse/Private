/*Program prebere starost in te�o treh �tudenov in izpi�e
 * Vpi�i starost in te�o 1. �tudenta: 20 75 
 * Vpi�i starost in te�o 2. �tudenta: 22 73
 * Vpi�i starost in te�o 3. �tudenta: 22 80
 * Povpre�na starost: 21.3333
 * Povrpe�na te�a:76 */
package v25_1;

import java.util.Scanner;

public class V1_6 {

	public static void main(String[] args) {
		//ustvarimo objekt za delo s tipkovnico
		Scanner tipkovnica = new Sccanner (System.in);
		
		//najva spremenljivk
		int starost1, starost2, starost3; //celo�tevil�ne vrednosti
		float teza1, teza2, teza3; //realne vrednosti 
		//branje oz. vnost vrednosti
		System.out.print("Starost in te�a 1. �tudenta: ");
		starost1 = tipkovnica.nextInt();
		teza1 = tipkovnica.nextFloat();
		
		System.out.print("Starost in te�a 2. �tudenta: ");
		starost2 = tipkovnica.nextInt();
		teza2 = tipkovnica.nextFloat();
		
		System.out.print("Starost in te�a 3. �tudenta: ");
		starost3 = tipkovnica.nextInt();
		teza3 = tipkovnica.nextFloat();
		
		//zapremo vhodni tok, delo s tipkovnico 
		tipkovnica.close();
		
		// izpis povre�ne starosti
		
		System.out.printf("\nPovpre�je - starost: %.2f ",(starost1 + starost2 + starost3) /3.0);
		
		// izpis povre�ne te�e
		
		System.out.printf("\nPovpre�je - teza: %.2f ", (teza1 + teza2 + teza3) / 3.0);
				
		
		
		
		
		
		
		
		
	}//main

}
