import java.util.Scanner;

/* �tetje �tevila pojavitev posamezne ocene od 1 do 5
 */



public class Switch_P2 {

	public static void main(String[] args) {
		//dekleracija in inicializacija �tevcev 
		int st1=0, st2=0, st3=0, st4=0, st5=0;
		//ustvarimo objek za branje 
		Scanner tipkovnica = new Scanner(System.in);
		// deklaracija spremenljivke za vnos ocene 1 - 5
		int ocena;
		do {
			//obvestilo za vnos
			System.out.print("Ocena: ");
			//branje 
			ocena = tipkovnica.nextInt(); 
			// pove�amo ustrezni �tevec pojavitve ocen
			switch (ocena) {
				// v primeru
				case 1: 
					st1 = st1 + 1; // ali st1++
					break; 
				case 2: 
					st2 = st2 + 1; 
					break; 
				case 3: 
					st3 = st3 + 1; 
					break; 
				case 4: 
					st4 = st4 + 1; 
					break; 
				case 5: 
					st5 = st5 + 1; // v zadni veji ne potrebujemo break	
					
			}//switch
			
		} while (ocena != -1); // dokler je ocena razli�na od -1.
		// zapremo vhodni tok
		tipkovnica.close();
		//izpis 
		System.out.printf("\nOcena %d => �tevilo pojavitev: %d.", 1, st1);
		System.out.printf("\nOcena %d => �tevilo pojavitev: %d.", 2, st2);
		System.out.printf("\nOcena %d => �tevilo pojavitev: %d.", 3, st3);
		System.out.printf("\nOcena %d => �tevilo pojavitev: %d.", 4, st4);
		System.out.printf("\nOcena %d => �tevilo pojavitev: %d.", 5, st5);
	}//main

}//razred Switch_P2
