import java.util.Scanner;

public class V {

	public static void main(String[] args) {
		//vpis �tevila
		System.out.print("�tevilo: ");
		//branje
     int stevilo = new Scanner(System.in).nextInt();
      
     //do while
     do {
    	
		System.out.printf("\n %d", stevilo);
		stevilo = stevilo - 1;
		
	} while (stevilo > 0);

	}

}
