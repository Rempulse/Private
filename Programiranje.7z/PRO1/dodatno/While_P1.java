import java.util.Scanner;

/* 
Primer z zmanj�evanjem �tevca.
Uporabnik vpi�e pozitivno celo �tevilo.
Program na zaslon izpi�e seznam �tevil od vnesenega �tevila do �tevila 1.
Padajo�e po koraku 1 */
public class While_P1 {
	

	public static void main(String[] args) {
		// najava spremenljivke za �tevilo
		int stevilo; 
		// branje z uporabo anonimnega objekta 
		System.out.print("�tevilo: ");
		stevilo = new Scanner(System.in).nextInt();
		//zanka while, dokler je vrednost stevilo > 0
		while (stevilo > 0 ) {
			//izpis vrednosti na zaslon
			System.out.printf("\n%d", stevilo);
			//zmanj�amo vrednost spremenljivke stevilo
			stevilo = stevilo -1;
		}//konec while

	} // main

}// class
