package p2901;
import java.util.Scanner;

public class V2_41 {
/* Uporabnik za tri študente vnese višino študentov. Program izpiše višine študentov po vrsti od največjega do najmanjšega.
Višina 1. študenta: 180
Višina 2. študenta: 185
Višina 3. študenta: 165
Urejene višine študentov: 185, 180, 165. */


public static void main(String[] args) {
	//dekleracija treh spremenljivk
	float visina1, visina2 , visina3;
	// ustvarimo objekt za delo s tipkovnico
	Scanner tipkovnica = new Scanner(System.in);
	//obvestilo za vnos
	System.out.print("Višina 1. študenta: ");
	visina1= tipkovnica.nextFloat();
	System.out.print("Višina 2. študenta: ");
	visina2= tipkovnica.nextFloat();
	System.out.print("Višina 3. študenta: ");
	visina3= tipkovnica.nextFloat();
	//zapremo objekt vhodnega toka
	tipkovnica.close();
    if (visina1 > visina2 && visina1 > visina3) {
    	//visina 1 je največji
    	System.out.print(visina1 + " ");
    	if (visina2 > visina3)
    	
    		System.out.printf("%.0f %.0f", visina2, visina3);
    	else 
    		System.out.printf("%.0f %.0f", visina3, visina2);
    	
    
    }
     else 
    	if (visina2 > visina3 ) {
    		//visina 2 je največji
        	System.out.print(visina2 + " ");
        	if (visina1 > visina3)
            	
        		System.out.printf("%.0f %.0f", visina1, visina3);
        	else 
        		System.out.printf("%.0f %.0f", visina3, visina1);
        	
    	}
    	else {
            //visina 3 je največji
	        System.out.print(visina3 + " ");
	        if (visina1 > visina2)
	        	
	    		System.out.printf("%.0f %.0f", visina1, visina2);
	    	else 
	    		System.out.printf("%.0f %.0f", visina2, visina1);

		
    	}
}

