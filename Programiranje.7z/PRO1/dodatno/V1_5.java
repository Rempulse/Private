/* Program prebere celo�tevil�ni vrednosti dveh spremenljivk x in y
 * Program zamenja vrednosti spremenljivk in izpi�e nove vrednosti na zaslon  */


package v25_1;

import java.util.Scanner;

public class V1_5 {

	public static void main(String[] args) {
		// deklaracija spremenljivk
		int x,y;
		// ustvarimo objekt za delo s tipkovnico
		Scanner tipkovnica = new Scanner(System.in);
		// obvestilo za vnos
		System.out.print("Prvo �tevilo: ");
		x = tipkovnica.nextInt(); // v x shranimo vrednost vpisanega �tevila
		System.out.print("Drugo �tevilo: ");
		y = tipkovnica.nextInt(); // v y shranimo vrednost vpisanega �tevila
		tipkovnica.close(); // zapremo vhodi tok, yapremo delo s tipkovnico
		// izvedemo zamenjavo vrednosti spremeljivk x in y
		// deklariramo uporabo pomo�ne spremenljivke
		int pom;
		// stavki za zamenjavo 
		pom = x;
		x = y;
		y = pom;
		//izpis po zamenjavi (konzolno okno)
		System.out.printf("Nova vrednost prvega �tevila: %d. ", x);
		System.out.printf("\nNova vrednost drugega �tevila: %d. ", y);
		
		

	}//main

}//V1_5
