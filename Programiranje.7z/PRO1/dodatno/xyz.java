package p2901;

import java.util.Scanner;
// Program, ki za ti vmesna realna �tevila preveri, �e velja tranzitivnost 
// x > y in y > z sledi (=>) x > z
// Vnesi tri �tevila (x y z): 67 56 54
// 67>56 in 67>54        => 67>54:Pravilo tranzitivnosti velja
public class xyz {

	public static void main(String[] args) {
		
		//dekleracija treh realnih �tevil
		float x,y,z;
		//ustvarimo objekt za branje
		Scanner tipkovnica = new Scanner(System.in);
		//obvestilo
		System.out.print("Vnesi tri �tevila (x y z): ");
		//branje treh �tevil
		x= tipkovnica.nextFloat();
		y= tipkovnica.nextFloat();
		z= tipkovnica.nextFloat();
		// zapremo delo s tipkovnico
		tipkovnica.close();
		// preverimo pogoj tranzitivnosti
		if (x >= y && y >= z)
		   {
			System.out.printf("Tranzitivnost velja; %.2f >= %.2f", x, z);
		   }
		else
		   {
			System.out.printf("Tranzitivnost ne velja; %.2f ni >= %.2f", x, z);
		   }// if
		
	}//main
}//clas
