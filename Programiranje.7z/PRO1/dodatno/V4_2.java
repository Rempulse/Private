package ve�kratniki;

public class V4_2 {
	public static void main (String[]args) {
		
		int stevec = 1;
		int izpisano = 0;
		while (stevec <= 100) {
			int stevilo = (int) (Math.random() * (500-50)+50);
			if (stevilo%2==0 || stevilo%4==0 || stevilo%7==0){
				System.out.printf("%4d ",stevilo);
				izpisano++;
			}
			if (stevec%10 == 0)
				System.out.println();
			stevec = stevec + 1;
			
		}
	}
}
