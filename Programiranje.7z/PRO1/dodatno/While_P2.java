import java.util.Scanner;

/* Za 10 vpisanih �tevil => 
   Izra�un vsote sodih in lihih �tevil */
public class While_P2 {

	public static void main(String[] args) {
		//dekleracija in inicializacija spremenljivk
		int i = 1; //stevec i
	    int vsotaSoda = 0, vsotaLiha = 0; //vsote na 0 
	    int stevilo; // spremenljivka za shranjevanje vnosa �tevila
	    // ustvarimo ojekt za delo s tipkovnico 
	    Scanner tipkovnica = new Scanner(System.in);
	    //zanka - ponavljanje, i = 1...10
	    
	    while (i <= 10) {
	    	//obvestilo za vnos
	    	System.out.printf("%d. �tevilo : ", i);
	    	//branje 
	    	stevilo = tipkovnica.nextInt();
	    	// ali je ostanek po celo�tevil�nem deljenjeu z 2 enak 0
	    	if (stevilo % 2 == 0) 
	    	// pove�amo vsoto sodih �tevil 
	    		vsotaSoda = vsotaSoda + stevilo;
	    	else
	    		//pove�amo vsoto lihih �tevil
	    	    vsotaLiha= vsotaLiha + stevilo; //konec if 
	    	// sprememba �tevca 
	    	    i = i + 1;
			
		}// konec while 
	    //zapremo vhodni tok
	    tipkovnica.close();
	    //izpis vsot
	    System.out.printf("Vsoti => soda: %d, liha: %d.",
	    		vsotaSoda, vsotaLiha);
	  
	}// main

}// class 
