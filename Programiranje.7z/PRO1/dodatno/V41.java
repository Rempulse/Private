package ve�kratniki;

import java.util.Scanner;

public class V41 {
	public static void main (String[]args) {
		
		//Vnos �tevila
		int n;
		Scanner tipkovnica = new Scanner (System.in);
		
		//Spremenljivka za nadaljevanje
		
		String nadaljevanje;
		
		do{
			System.out.print("�tevilo: ");

		n=tipkovnica.nextInt();
		
		//Izra�un fakultete �tevila n, n!
		
		//Spremenljivka za izra�un
		long fakulteta = 1;
		int i = 1; //�tevec
		
		while (i <= n) {
			
			fakulteta=fakulteta*i;
		
			//Pove�evanje �tevca
			
			i = i + 1;
		}
		System.out.printf("%d! = %d.", n, fakulteta);
		System.out.print("\n�elite nadaljevati <D|N>: ");
		nadaljevanje = tipkovnica.next();
		} while(nadaljevanje.toUpperCase().charAt(0) != 'N');
		tipkovnica.close();
	}
}
