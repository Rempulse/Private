package p2901;
import java.util.Scanner;

public class V2_3 {
/* Uporabnik za tri študente vnese višino študentov. Program izpiše višine študentov po vrsti od največjega do najmanjšega.
Višina 1. študenta: 180
Višina 2. študenta: 185
Višina 3. študenta: 165
Urejene višine študentov: 185, 180, 165. */


public static void main(String[] args) {
	//dekleracija treh spremenljivk
	float visina1, visina2 , visina3;
	// ustvarimo objekt za delo s tipkovnico
	Scanner tipkovnica = new Scanner(System.in);
	//obvestilo za vnos
	System.out.print("Višina 1. študenta: ");
	visina1= tipkovnica.nextFloat();
	System.out.print("Višina 2. študenta: ");
	visina2= tipkovnica.nextFloat();
	System.out.print("Višina 3. študenta: ");
	visina3= tipkovnica.nextFloat();
	//zapremo objekt vhodnega toka
	tipkovnica.close();
	// če je drug večji od prvega => zamenjava
	
	if ( visina2 > visina1)  {
	float pomozna = visina1;
	   visina1 = visina2;
	   visina2 = pomozna; 
	   
	} //if
	  
	// če je tretnji večji od prvega => zamenjava
	if ( visina3 > visina1)
	   {float pomozna = visina1;
	   visina1 = visina3;
	   visina3 = pomozna; 
	   }//if
	//če je tretji večji od drugega => zamenjava 
	   if ( visina3 > visina2)
	   {float pomozna = visina1;
	   visina2 = visina3;
	   visina3 = pomozna;
	   }//if
	   
	   //izpis
		System.out.printf("Višine od največje do najmanše; %.0f,  %.0f, %.0f", 
				visina1, visina2, visina3);
		
		
		
			
		
	}// main

}// razred
