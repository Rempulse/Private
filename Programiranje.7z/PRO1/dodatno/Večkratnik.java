package ve�kratniki;

public class Ve�kratnik {
	public static void main (String[]args) {
		
	int i = 4;
	while (i<=100) {
		System.out.println(i);
		i=i+4;
	}
	}
}
