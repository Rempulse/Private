/*Program za izračun fakultete vnesenega celega Števila.

Število vnese uporabnik.

Izračun fakultete se izvaja dokler uporabnik na vpraŠanje "ŽeliŠ nadaljevati (D/N)?" ne odgovori z "N".*/
import java.util.Scanner;

public class Fakulteta {

	public static void main(String[] args) {
		// ustvarimo objekt za tipkovnico
		Scanner tipkovnica = new Scanner(System.in);
		//dekleracija spremenljivke za vpis števila
		int stevilo;
		//objekt niza za nadaljevanje
		String nadaljevanje;
		//ponavaljanje, izvrši se vsaj enkrat
		do {
		//obvestilo za vnos
		System.out.print("Število <N>: ");
		//branje 
		stevilo = tipkovnica.nextInt();
		//inicializacija izračuna
		int i=2; // števec 1..n
		long fakulteta = 1; //-1 nevtralni element za množenje 0!=1
		// while stavek 
		while (i <= stevilo) { //dokler je števec <= število
			fakulteta = fakulteta *i;
		   //povečamo števec
			i = i + 1;
		} //zanka while	
		//izpišemo rezlutat
		System.out.printf("Fakulteta %d je: %d.", stevilo, fakulteta);
		//izpis obvestila za nadaljevanje
		System.out.print("\nNadaljevanje <DA|NE>: ");
		nadaljevanje = tipkovnica.next();//branje niza
		
		} while (nadaljevanje.toUpperCase().charAt(0) != 'N'); //do while
		
	}//main

}//class
