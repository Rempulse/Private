package p2901;
//uporabnik vpi�e en znak
// profram izpi�e cifra (0, 1,2..9) sicer 
// napi�e drug znak

public class P2_if {

	public static void main(String[] args) {
	//najava spremenljivke 
	char znak;
	System.out.print("Vpi�i znak: ");
	znak = new Scanner(System.in).next().charAt(0); //vrne prvi znak vpisanega 
	// test cifra 
	if (znak >= '0' && znak <= '9')
		System.out.print("Vpisali ste cifro.")
		else
		System.out.print("Niste vpisali cifro.");
	
		
		
		

	}

}
