/*Program v tabelo nakljucna ustvari 100 naključnih Števil iz intervala od 50 do 500.
Na koncu izpiŠe Še Število teh Števil. */
public class NakljucnoStevilo {

	public static void main(String[] args) {
		//zanka, števec i = 1...100
		int i = 1;
		int nakljucnoStevilo;
		
		while (i <= 100) {
		// ustvarimo naključno število
			//metoda.Math.random() vrne naključno število me 0 in < 1
			
			nakljucnoStevilo = (int) (Math.random() * (500-50) + 50);
			
			System.out.println(nakljucnoStevilo);
			i = i + 1;
			
		}//konec while
		
		

	}//main

}// class
