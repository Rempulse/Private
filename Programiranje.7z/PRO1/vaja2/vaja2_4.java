package vaja2;

import java.util.Scanner;

public class vaja2_4 {
	public static void main(String[]args){
		
		float visina, teza, rezultat;
		
		Scanner tipkovnica = new Scanner(System.in);
		
		System.out.print("Vnos visine: ");
		visina = tipkovnica.nextFloat();
		
		System.out.print("Vnos teze: ");
		teza = tipkovnica.nextFloat();
		
		tipkovnica.close();
		
		rezultat = (teza/(visina*visina));
		
		System.out.print(rezultat+" ");
		
		if (rezultat <= 18.5)
			System.out.print("Premajhna te�a");
		else {
			if (rezultat >= 18.5 && rezultat <= 25.5)
				System.out.print("Normalna te�a");
			else {
				if (rezultat >= 25.5)
					System.out.print("Prevelika te�a");
			}
		}
	}

}
