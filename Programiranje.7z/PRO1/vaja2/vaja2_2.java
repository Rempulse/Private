package vaja2;

import java.util.Scanner;

public class vaja2_2 {
	public static void main(String[] args) {
		
		float x,y,z;
		
		Scanner tipkovnica = new Scanner(System.in);
		System.out.print("Vnos treh �tevil: ");
		
		x=tipkovnica.nextFloat();
		y=tipkovnica.nextFloat();
		z=tipkovnica.nextFloat();
		tipkovnica.close();
		
		if (x >= y && y >= z)
			System.out.printf("Tranzitivnost velja; %.2f >= %.2f", x, z);
		else
			System.out.printf("Tranzitivnost ne velja; %.2f >= %.2f", x, z);
	}

}
