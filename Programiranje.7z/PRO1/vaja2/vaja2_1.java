package vaja2;

import java.util.Scanner;

public class vaja2_1 {
	public static void main(String[]args) {
		
		float stevilo1, stevilo2;
		
		Scanner tipkovnica = new Scanner(System.in);
		System.out.print("Vnos dveh �tevil: ");
		
		stevilo1=tipkovnica.nextFloat();
		stevilo2=tipkovnica.nextFloat();
		tipkovnica.close();
		
		if (stevilo1 > stevilo2)
			System.out.printf("\\n %.2f > %.2f: %s", stevilo1, stevilo2, "resni�no");
		else
			System.out.printf("\\n %.2f > %.2f: %s", stevilo1, stevilo2, "neresni�no");
		
		if (stevilo1 >= stevilo2)
			System.out.printf("\\n %.2f > %.2f: %s", stevilo1, stevilo2, "resni�no");
		else
			System.out.printf("\\n %.2f > %.2f: %s", stevilo1, stevilo2, "neresni�no");
		
		if (stevilo1 < stevilo2)
			System.out.printf("\\n %.2f > %.2f: %s", stevilo1, stevilo2, "resni�no");
		else
			System.out.printf("\\n %.2f > %.2f: %s", stevilo1, stevilo2, "neresni�no");
		
		if (stevilo1 <= stevilo2)
			System.out.printf("\\n %.2f > %.2f: %s", stevilo1, stevilo2, "resni�no");
		else
			System.out.printf("\\n %.2f > %.2f: %s", stevilo1, stevilo2, "neresni�no");
		
		if (stevilo1 != stevilo2)
			System.out.printf("\\n %.2f > %.2f: %s", stevilo1, stevilo2, "resni�no");
		else
			System.out.printf("\\n %.2f > %.2f: %s", stevilo1, stevilo2, "neresni�no");
		
		if (stevilo1 == stevilo2)
			System.out.printf("\\n %.2f > %.2f: %s", stevilo1, stevilo2, "resni�no");
		else
			System.out.printf("\\n %.2f > %.2f: %s", stevilo1, stevilo2, "neresni�no");
	}

}
