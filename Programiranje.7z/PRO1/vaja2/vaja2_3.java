package vaja2;

import java.util.Scanner;

public class vaja2_3 {
	public static void main(String[]args) {
		
		float visina1, visina2, visina3;
		
		Scanner tipkovnica = new Scanner(System.in);
		
		System.out.print("Vnos visina1: ");
		visina1=tipkovnica.nextFloat();
		
		System.out.print("Vnos visina2: ");
		visina2=tipkovnica.nextFloat();
		
		System.out.print("Vnos visina3: ");
		visina3=tipkovnica.nextFloat();
		
		tipkovnica.close();
		
		if(visina2 > visina1) {
			float pomozna = visina1;
			visina1 = visina2;
			visina2 = pomozna;
		}
		
		if(visina3 > visina2) {
			float pomozna = visina1;
			visina2 = visina3;
			visina3 = pomozna;
		}
		
		System.out.printf("Vi�ine od najve�je do najman�e: %.0f,  %.0f, %.0f", 
				visina1, visina2, visina3);
			
	}

}
