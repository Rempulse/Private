package package1;

//Program izpi�e stavek

public class vaja1 {
	public static void main(String[] args) {
		System.out.printf("To je prvi primer na vajah.");
	}
}