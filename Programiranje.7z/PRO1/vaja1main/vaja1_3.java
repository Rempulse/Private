package package1;

import java.util.Scanner;

//Program izpi�e vsoto dveh �tevil

public class vaja1_3 {
	public static void main(String[] args) {
		
		//Integer za cela �tevila
		
		int  stevilo1, stevilo2;
		
		Scanner tipkovnica = new Scanner (System.in);
		System.out.printf("Vpi�i dve celi �tevili: ");
		stevilo1 = tipkovnica.nextInt();
		stevilo2 = tipkovnica.nextInt();
		
		//Izra�un vsote dveh �tevil

		int vsota = stevilo1 + stevilo2;
		
		System.out.printf("Vsota �tevil: %d + %d = %d.",
		stevilo1, stevilo2, vsota);
		tipkovnica.close();
	}
}