package package1;

//Program izpi�e podatke

public class vaja1_2 {
	public static void main(String[] args) {
		System.out.printf("Ime: \t\tIrfan\n");
		System.out.println("Priimek: \tMujakic");
		System.out.printf("E-naslov: \tgmail@gmail.com");
	}
}