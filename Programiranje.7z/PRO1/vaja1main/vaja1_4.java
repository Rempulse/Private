package package1;

import java.util.Scanner;

//Program za izra�un plo��ine in obsega pravokotnika.

public class vaja1_4 {
	public static void main(String[] args) {
		
		//Float za decimalni vnos
		
		float stranicaA,  stranicaB;
		
		//Scanner
		
		Scanner tipkovnica = new Scanner (System.in);
		System.out.printf("Vpi�i dve stranici: ");
		stranicaA = tipkovnica.nextFloat();
		stranicaB = tipkovnica.nextFloat();
		
		//Izra�un obsega pravokotnika
		
		float obseg= (stranicaA * 2) + (stranicaB * 2);
		System.out.printf("Obseg pravokotnika: %.2f", obseg);
		
		//Izra�un plo��ine pravokotnika
		
		float ploscina= stranicaA * stranicaB;
		System.out.printf("Obseg pravokotnika:%.2f", ploscina);
		tipkovnica.close();
	}
}